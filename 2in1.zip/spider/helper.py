﻿
# -*- coding: utf-8 -*-
# Source Code : NoobLess Team #
# Arfine Meka.
# 
# -*- coding: utf-8 -*-
# ------------------------ IMPORT ------------------------ #

import time, random, sys, json, codecs, glob, urllib, pytz, ast, os, multiprocessing, subprocess, tempfile, string, six, urllib.parse, traceback, atexit, html5lib, re, wikipedia, ntpath, threading, base64, shutil, humanize, service, os.path, youtube_dl, requests
import urllib3
urllib3.disable_warnings()
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ------------------------ IMPORT ------------------------ #

from LineAPI.linepy import *
from LineAPI.akad.ttypes import *
from LineAPI.akad import ChannelService,TalkService
from LineAPI.akad.ttypes import Message, Location, LoginRequest, ChatRoomAnnouncementContents, ContentType as Type
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from thrift.protocol import TCompactProtocol, TBinaryProtocol, TProtocol
from thrift.transport import THttpClient, TTransport
from thrift.Thrift import TProcessor
from multiprocessing import Pool, Process
from multiprocessing.dummy import Pool as ThreadPool
from threading import Thread, activeCount
from time import sleep
from datetime import datetime, timedelta
from humanfriendly import format_timespan, format_size, format_number, format_length
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# ------------------------ LOGIN ------------------------ #
noobcoder = LINE()
noobcoderMid = noobcoder.profile.mid
noobcoderProfile = noobcoder.getProfile()
clientSettings = noobcoder.getSettings()
mid = noobcoder.getProfile().mid
noobcoderMID = noobcoder.getProfile().mid
noobcoderPoll = OEPoll(noobcoder)
botStart = time.time()
msg_send = {}
temp_flood = {}
tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)
creator = ['ubcd98265d4210c2215f3ddb43d79c414']
adminbots = ['ubcd98265d4210c2215f3ddb43d79c414']
superz = creator + adminbots
with open('by.json', 'r') as fp:
    wait = json.load(fp)
settings ={"keyCommand":"","setKey":False}

ugh = {
    "postId": [],
}
autoR = {
    "autoRead": True,
}
autoR1 = {
    "autoRead1": True,
}
join = {
    "autoJoin": True,
}
mcroom = {
    "leaveMc": True,
}
def logincok():
    Headers5 = {
    'User-Agent': "Line/8.9.1",
    'X-Line-Application': "IOSIPAD\t11.2.5\tiPhone X\t11.2.5",
    "x-lal": "ja-US_US",
    }
    return Headers5

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d วัน %02d ชั่วโมง %02d นาที %02d วินาที' % (days, hours, mins, secs)

def restartBot():
    print ("[ INFO ] BOT RESTART")
    python = sys.executable
    os.execl(python, python, *sys.argv)
        
def backupData():
    try:
        backup = wait
        f = codecs.open('by.json','w','utf-8')
        json.dump(wait, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except:
        e = traceback.format_exc()
        noobcoder.sendMessage("ubcd98265d4210c2215f3ddb43d79c414",str(e))
        return False
def sendTemplate(to, data):
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def sendFooter(to, isi):
    data = {
        "type": "text",
        "text": isi,
        "sentBy": {
            "label": "PRINCE & ShahZain",
            "iconUrl": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),
            "linkUrl": "line://nv/profilePopup/mid=ubcd98265d4210c2215f3ddb43d79c414"
        }
    }
    sendTemplate(to, data)

def sendMention(to, mid, firstmessage='', lastmessage=''):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        try:
            noobcoder.sendMessage(to, text, {'MSG_SENDER_NAME': noobcoder.getContact(mid).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact(mid).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        except Exception as e:
            noobcoder.sendMessage(to, text, {'MSG_SENDER_NAME': noobcoder.getContact("ubcd98265d4210c2215f3ddb43d79c414").displayName,'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + noobcoder.getContact("ubcd98265d4210c2215f3ddb43d79c414").pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        print(error)

def mentions(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@Rbs Gans  "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    noobcoder.sendMessage(to, textx, {'AGENT_NAME':'LINE OFFICIAL', 'AGENT_LINK': 'line://ti/p/~{}'.format(noobcoder.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact("ubcd98265d4210c2215f3ddb43d79c414").picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def tagdia(to, text="",ps='', mids=[]):
        arrData = ""
        arr = []
        mention = "@MentionOrang "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 13
                else:slen = len(textx);elen = len(textx) + 13
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        noobcoder.sendMessage(to, textx, {'MSG_SENDER_NAME': noobcoder.getContact(ps).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact(ps).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        
def command(text):
    pesan = text.lower()
    if settings["setKey"] == True:
        if pesan.startswith(settings["keyCommand"]):
            cmd = pesan.replace(settings["keyCommand"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
    
def noobcoderBot(op):
    try:
        if op.type == 0:
            return   
                
        if op.type in [22,24]:
                noobcoder.leaveRoom(op.param1)
            
        if op.type == 13:
            if noobcoder.getProfile().mid in op.param3:
                G = noobcoder.getCompactGroup(op.param1)
                if join["autoJoin"] == True:
                    noobcoder.acceptGroupInvitation(op.param1)
                    mentions(op.param1,"Hallo @! Type Help To see your command",[op.param2])

        if op.type in [22,24]:
            noobcoder.leaveRoom(op.param1)
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != noobcoderMID: to = sender
                else: to = receiver
                if msg.contentType == 16:
                    if msg._from in wait["info"]:
                        if msg.toType in [2,1,0]:
                            try:
                                purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                                if purl[1] not in ugh['postId']:
                                    noobcoder1.likePost(purl[0], purl[1], 1003)
                                    noobcoder2.likePost(purl[0], purl[1], 1003)
                                    noobcoder3.likePost(purl[0], purl[1], 1003)
                                    noobcoder4.likePost(purl[0], purl[1], 1003)
                                    noobcoder5.likePost(purl[0], purl[1], 1003)
                                    noobcoder6.likePost(purl[0], purl[1], 1003)
                                    noobcoder7.likePost(purl[0], purl[1], 1003)
                                    noobcoder8.likePost(purl[0], purl[1], 1003)
                                    noobcoder9.likePost(purl[0], purl[1], 1003)
                                    noobcoder10.likePost(purl[0], purl[1], 1003)
                                    noobcoder11.likePost(purl[0], purl[1], 1003)
                                    noobcoder12.likePost(purl[0], purl[1], 1003)
                                    noobcoder13.likePost(purl[0], purl[1], 1003)
                                    noobcoder14.likePost(purl[0], purl[1], 1003)
                                    noobcoder15.likePost(purl[0], purl[1], 1003)
                                    noobcoder16.likePost(purl[0], purl[1], 1003)
                                    noobcoder17.likePost(purl[0], purl[1], 1003)
                                    noobcoder18.likePost(purl[0], purl[1], 1003)
                                    noobcoder19.likePost(purl[0], purl[1], 1003)
                                    noobcoder20.likePost(purl[0], purl[1], 1003)
                                    noobcoder21.likePost(purl[0], purl[1], 1003)
                                    noobcoder22.likePost(purl[0], purl[1], 1003)
                                    noobcoder23.likePost(purl[0], purl[1], 1003)
                                    noobcoder24.likePost(purl[0], purl[1], 1003)
                                    noobcoder25.likePost(purl[0], purl[1], 1003)
                                    noobcoder26.likePost(purl[0], purl[1], 1003)
                                    noobcoder27.likePost(purl[0], purl[1], 1003)
                                    noobcoder28.likePost(purl[0], purl[1], 1003)
                                    noobcoder29.likePost(purl[0], purl[1], 1003)
                                    noobcoder30.likePost(purl[0], purl[1], 1003)
                                    noobcoder31.likePost(purl[0], purl[1], 1003)
                                    noobcoder32.likePost(purl[0], purl[1], 1003)
                                    noobcoder33.likePost(purl[0], purl[1], 1003)
                                    noobcoder34.likePost(purl[0], purl[1], 1003)
                                    noobcoder35.likePost(purl[0], purl[1], 1003)
                                    noobcoder36.likePost(purl[0], purl[1], 1003)
                                    noobcoder37.likePost(purl[0], purl[1], 1003)
                                    noobcoder38.likePost(purl[0], purl[1], 1003)
                                    noobcoder39.likePost(purl[0], purl[1], 1003)
                                    noobcoder40.likePost(purl[0], purl[1], 1003)
                                    noobcoder41.likePost(purl[0], purl[1], 1003)
                                    noobcoder42.likePost(purl[0], purl[1], 1003)
                                    noobcoder43.likePost(purl[0], purl[1], 1003)
                                    noobcoder44.likePost(purl[0], purl[1], 1003)
                                    noobcoder45.likePost(purl[0], purl[1], 1003)
                                    noobcoder46.likePost(purl[0], purl[1], 1003)
                                    noobcoder47.likePost(purl[0], purl[1], 1003)
                                    noobcoder48.likePost(purl[0], purl[1], 1003)
                                    noobcoder49.likePost(purl[0], purl[1], 1003)
                                    noobcoder50.likePost(purl[0], purl[1], 1003)
                                    noobcoder51.likePost(purl[0], purl[1], 1003)
                                    noobcoder52.likePost(purl[0], purl[1], 1003)
                                    noobcoder53.likePost(purl[0], purl[1], 1003)
                                    noobcoder54.likePost(purl[0], purl[1], 1003)
                                    noobcoder55.likePost(purl[0], purl[1], 1003)
                                    noobcoder56.likePost(purl[0], purl[1], 1003)
                                    noobcoder57.likePost(purl[0], purl[1], 1003)
                                    noobcoder58.likePost(purl[0], purl[1], 1003)
                                    noobcoder59.likePost(purl[0], purl[1], 1003)
                                    noobcoder60.likePost(purl[0], purl[1], 1003)
                                    noobcoder61.likePost(purl[0], purl[1], 1003)
                                    noobcoder62.likePost(purl[0], purl[1], 1003)
                                    noobcoder63.likePost(purl[0], purl[1], 1003)
                                    noobcoder64.likePost(purl[0], purl[1], 1003)
                                    noobcoder65.likePost(purl[0], purl[1], 1003)
                                    noobcoder66.likePost(purl[0], purl[1], 1003)
                                    noobcoder67.likePost(purl[0], purl[1], 1003)
                                    noobcoder68.likePost(purl[0], purl[1], 1003)
                                    noobcoder69.likePost(purl[0], purl[1], 1003)
                                    noobcoder70.likePost(purl[0], purl[1], 1003)
                                    noobcoder71.likePost(purl[0], purl[1], 1003)
                                    noobcoder72.likePost(purl[0], purl[1], 1003)
                                    noobcoder73.likePost(purl[0], purl[1], 1003)
                                    noobcoder74.likePost(purl[0], purl[1], 1003)
                                    noobcoder75.likePost(purl[0], purl[1], 1003)
                                    noobcoder76.likePost(purl[0], purl[1], 1003)
                                    noobcoder77.likePost(purl[0], purl[1], 1003)
                                    noobcoder78.likePost(purl[0], purl[1], 1003)
                                    noobcoder79.likePost(purl[0], purl[1], 1003)
                                    noobcoder80.likePost(purl[0], purl[1], 1003)
                                    noobcoder81.likePost(purl[0], purl[1], 1003)
                                    noobcoder82.likePost(purl[0], purl[1], 1003)
                                    noobcoder83.likePost(purl[0], purl[1], 1003)
                                    noobcoder84.likePost(purl[0], purl[1], 1003)
                                    noobcoder85.likePost(purl[0], purl[1], 1003)
                                    noobcoder86.likePost(purl[0], purl[1], 1003)
                                    noobcoder87.likePost(purl[0], purl[1], 1003)
                                    noobcoder88.likePost(purl[0], purl[1], 1003)
                                    noobcoder89.likePost(purl[0], purl[1], 1003)
                                    noobcoder90.likePost(purl[0], purl[1], 1003)
                                    noobcoder91.likePost(purl[0], purl[1], 1003)
                                    noobcoder92.likePost(purl[0], purl[1], 1003)
                                    noobcoder93.likePost(purl[0], purl[1], 1003)
                                    noobcoder94.likePost(purl[0], purl[1], 1003)
                                    noobcoder95.likePost(purl[0], purl[1], 1003)
                                    noobcoder96.likePost(purl[0], purl[1], 1003)
                                    noobcoder97.likePost(purl[0], purl[1], 1003)
                                    noobcoder98.likePost(purl[0], purl[1], 1003)
                                    noobcoder99.likePost(purl[0], purl[1], 1003)
                                    noobcoder100.likePost(purl[0], purl[1], 1003)
                                    sendFooter(to, "Your post has been liked")
                                    noobcoder.createComment(purl[0], purl[1],"AutoLike by Khie & Matz\n\nWanna Order ?\n\nContact Person:\nhttp://line.me/ti/p/~musibat83")
                                    ugh['postId'].append(purl[1])
                                else:
                                    pass
                            except Exception as e:
                                purl = msg.contentMetadata['postEndUrl'].split('homeId=')[1].split('&postId=')
                                if purl[1] not in ugh['postId']:
                                    noobcoder1.likePost(purl[0], purl[1], 1003)
                                    noobcoder2.likePost(purl[0], purl[1], 1003)
                                    noobcoder3.likePost(purl[0], purl[1], 1003)
                                    noobcoder4.likePost(purl[0], purl[1], 1003)
                                    noobcoder5.likePost(purl[0], purl[1], 1003)
                                    noobcoder6.likePost(purl[0], purl[1], 1003)
                                    noobcoder7.likePost(purl[0], purl[1], 1003)
                                    noobcoder8.likePost(purl[0], purl[1], 1003)
                                    noobcoder9.likePost(purl[0], purl[1], 1003)
                                    noobcoder10.likePost(purl[0], purl[1], 1003)
                                    noobcoder11.likePost(purl[0], purl[1], 1003)
                                    noobcoder12.likePost(purl[0], purl[1], 1003)
                                    noobcoder13.likePost(purl[0], purl[1], 1003)
                                    noobcoder14.likePost(purl[0], purl[1], 1003)
                                    noobcoder15.likePost(purl[0], purl[1], 1003)
                                    noobcoder16.likePost(purl[0], purl[1], 1003)
                                    noobcoder17.likePost(purl[0], purl[1], 1003)
                                    noobcoder18.likePost(purl[0], purl[1], 1003)
                                    noobcoder19.likePost(purl[0], purl[1], 1003)
                                    noobcoder20.likePost(purl[0], purl[1], 1003)
                                    noobcoder21.likePost(purl[0], purl[1], 1003)
                                    noobcoder22.likePost(purl[0], purl[1], 1003)
                                    noobcoder23.likePost(purl[0], purl[1], 1003)
                                    noobcoder24.likePost(purl[0], purl[1], 1003)
                                    noobcoder25.likePost(purl[0], purl[1], 1003)
                                    noobcoder26.likePost(purl[0], purl[1], 1003)
                                    noobcoder27.likePost(purl[0], purl[1], 1003)
                                    noobcoder28.likePost(purl[0], purl[1], 1003)
                                    noobcoder29.likePost(purl[0], purl[1], 1003)
                                    noobcoder30.likePost(purl[0], purl[1], 1003)
                                    noobcoder31.likePost(purl[0], purl[1], 1003)
                                    noobcoder32.likePost(purl[0], purl[1], 1003)
                                    noobcoder33.likePost(purl[0], purl[1], 1003)
                                    noobcoder34.likePost(purl[0], purl[1], 1003)
                                    noobcoder35.likePost(purl[0], purl[1], 1003)
                                    noobcoder36.likePost(purl[0], purl[1], 1003)
                                    noobcoder37.likePost(purl[0], purl[1], 1003)
                                    noobcoder38.likePost(purl[0], purl[1], 1003)
                                    noobcoder39.likePost(purl[0], purl[1], 1003)
                                    noobcoder40.likePost(purl[0], purl[1], 1003)
                                    noobcoder41.likePost(purl[0], purl[1], 1003)
                                    noobcoder42.likePost(purl[0], purl[1], 1003)
                                    noobcoder43.likePost(purl[0], purl[1], 1003)
                                    noobcoder44.likePost(purl[0], purl[1], 1003)
                                    noobcoder45.likePost(purl[0], purl[1], 1003)
                                    noobcoder46.likePost(purl[0], purl[1], 1003)
                                    noobcoder47.likePost(purl[0], purl[1], 1003)
                                    noobcoder48.likePost(purl[0], purl[1], 1003)
                                    noobcoder49.likePost(purl[0], purl[1], 1003)
                                    noobcoder50.likePost(purl[0], purl[1], 1003)
                                    noobcoder51.likePost(purl[0], purl[1], 1003)
                                    noobcoder52.likePost(purl[0], purl[1], 1003)
                                    noobcoder53.likePost(purl[0], purl[1], 1003)
                                    noobcoder54.likePost(purl[0], purl[1], 1003)
                                    noobcoder55.likePost(purl[0], purl[1], 1003)
                                    noobcoder56.likePost(purl[0], purl[1], 1003)
                                    noobcoder57.likePost(purl[0], purl[1], 1003)
                                    noobcoder58.likePost(purl[0], purl[1], 1003)
                                    noobcoder59.likePost(purl[0], purl[1], 1003)
                                    noobcoder60.likePost(purl[0], purl[1], 1003)
                                    noobcoder61.likePost(purl[0], purl[1], 1003)
                                    noobcoder62.likePost(purl[0], purl[1], 1003)
                                    noobcoder63.likePost(purl[0], purl[1], 1003)
                                    noobcoder64.likePost(purl[0], purl[1], 1003)
                                    noobcoder65.likePost(purl[0], purl[1], 1003)
                                    noobcoder66.likePost(purl[0], purl[1], 1003)
                                    noobcoder67.likePost(purl[0], purl[1], 1003)
                                    noobcoder68.likePost(purl[0], purl[1], 1003)
                                    noobcoder69.likePost(purl[0], purl[1], 1003)
                                    noobcoder70.likePost(purl[0], purl[1], 1003)
                                    noobcoder71.likePost(purl[0], purl[1], 1003)
                                    noobcoder72.likePost(purl[0], purl[1], 1003)
                                    noobcoder73.likePost(purl[0], purl[1], 1003)
                                    noobcoder74.likePost(purl[0], purl[1], 1003)
                                    noobcoder75.likePost(purl[0], purl[1], 1003)
                                    noobcoder76.likePost(purl[0], purl[1], 1003)
                                    noobcoder77.likePost(purl[0], purl[1], 1003)
                                    noobcoder78.likePost(purl[0], purl[1], 1003)
                                    noobcoder79.likePost(purl[0], purl[1], 1003)
                                    noobcoder80.likePost(purl[0], purl[1], 1003)
                                    noobcoder81.likePost(purl[0], purl[1], 1003)
                                    noobcoder82.likePost(purl[0], purl[1], 1003)
                                    noobcoder83.likePost(purl[0], purl[1], 1003)
                                    noobcoder84.likePost(purl[0], purl[1], 1003)
                                    noobcoder85.likePost(purl[0], purl[1], 1003)
                                    noobcoder86.likePost(purl[0], purl[1], 1003)
                                    noobcoder87.likePost(purl[0], purl[1], 1003)
                                    noobcoder88.likePost(purl[0], purl[1], 1003)
                                    noobcoder89.likePost(purl[0], purl[1], 1003)
                                    noobcoder90.likePost(purl[0], purl[1], 1003)
                                    noobcoder91.likePost(purl[0], purl[1], 1003)
                                    noobcoder92.likePost(purl[0], purl[1], 1003)
                                    noobcoder93.likePost(purl[0], purl[1], 1003)
                                    noobcoder94.likePost(purl[0], purl[1], 1003)
                                    noobcoder95.likePost(purl[0], purl[1], 1003)
                                    noobcoder96.likePost(purl[0], purl[1], 1003)
                                    noobcoder97.likePost(purl[0], purl[1], 1003)
                                    noobcoder98.likePost(purl[0], purl[1], 1003)
                                    noobcoder99.likePost(purl[0], purl[1], 1003)
                                    noobcoder100.likePost(purl[0], purl[1], 1003)
                                    sendFooter(to, "Your post has been liked")
                                    noobcoder.createComment(purl[0], purl[1],"AutoLike by Khie & Matz\n\nWanna Order ?\n\nContact Person:\nhttp://line.me/ti/p/~musibat83")
                                    ugh['postId'].append(purl[1])
                                else:pass
                if msg.contentType in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]:
                    if msg.toType == 0:
                        if autoR["autoRead"] == True:
                            noobcoder.sendChatChecked(to, msg_id)
                    if msg.toType == 2:
                        if autoR1["autoRead1"] == True:
                            noobcoder.sendChatChecked(to, msg_id)
                            
                if msg.contentType == 0:
                    if "/ti/g/" in text.lower():
                        if join["autoJoin"] == True:
                            link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                            links = link_re.findall(text)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                   n_links.append(l)
                            for ticket_id in n_links:
                                group = noobcoder.findGroupByTicket(ticket_id)
                                if len(group.members) >= wait["Members"]:
                                    noobcoder.acceptGroupInvitationByTicket(group.id,ticket_id)
                                else:
                                    noobcoder.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    noobcoder.leaveGroup(group.id)
            
        if op.type == 26:
            try:
                msg = op.message
                text = msg.text
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                    if msg.toType == 0:
                        if sender != noobcoder.profile.mid:
                            to = sender
                        else:
                            to = receiver
                    if msg.toType == 1:
                        to = receiver
                    if msg.toType == 2:
                        to = receiver
                    if msg.contentType == 0:
                        if text is None:
                            pass
                        else:
                            cmd = command(text)
                            if text.lower().startswith('# ') and sender in ['ubcd98265d4210c2215f3ddb43d79c414']:
                                a=subprocess.getoutput(noobcoder.mainsplit(msg.text))
                                k = len(a)//10000
                                for aa in range(k+1):
                                    try:
                                        noobcoder.generateReplyMessage(msg.id)
                                        noobcoder.sendReplyMessage(msg.id,to,'{}'.format(a.strip()[aa*10000 : (aa+1)*10000]))
                                    except:
                                        noobcoder.sendMessage(to, "Done")

                            if text.lower() == "renew" and sender in ['ubcd98265d4210c2215f3ddb43d79c414']:
                                try:
                                    sam = {'MSG_SENDER_ICON': "https://os.line.naver.jp/os/p/"+sender,'MSG_SENDER_NAME':  noobcoder.getContact(sender).displayName,}                            
                                    noobcoder.sendMessage(to, "Update Library Done", contentMetadata=sam)
                                    restartBot()
                                except:
                                    e = traceback.format_exc()
                                    noobcoder.sendMessage("ubcd98265d4210c2215f3ddb43d79c414",str(e))

                            if text.lower().startswith('adduser ') and sender in ['ubcd98265d4210c2215f3ddb43d79c414','u34eb2b4c78aac07087fc80b38e03a5b0']:
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    if key1 not in wait['info']:
                                        pay = time.time()
                                        nama = str(text.split(' ')[1])
                                        wait['name'][nama] =  {"mid":key1,"pay":pay+60*60*24*30,"runtime":pay,"token":{}}
                                        wait['info'][key1] =  '%s' % nama
                                        mentions(msg.to, ' 「 Add Service 」\nAdded @! to service',[key1])
                                    else:
                                        mentions(msg.to, ' 「 Add Service 」\nUser @! already in service',[key1])

                            if text.lower().startswith('nope ') and sender in ['ubcd98265d4210c2215f3ddb43d79c414','u34eb2b4c78aac07087fc80b38e03a5b0']:
                                sep = text.split(" ")
                                query = text.replace(sep[0] + " ","")
                                aa = [a for a in wait['info']]
                                try:
                                    listContact = aa[int(query)-1]
                                    if listContact in wait['info']:
                                        b = wait['info'][listContact]
                                        os.system('screen -S %s -X kill'%b)
                                        try:subprocess.getoutput('rm -rf {}'.format(b))
                                        except:pass
                                        del wait['info'][listContact]
                                        del wait['name'][b]
                                        mentions(to, ' 「 Add 」\n@!add to service', [listContact])
                                    else:
                                        mentions(to, ' 「 Add 」\n@!already in service', [listContact])
                                except:pass

                            if text.lower().startswith('deluser ') and sender in ['ubcd98265d4210c2215f3ddb43d79c414','u34eb2b4c78aac07087fc80b38e03a5b0']:
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    if key1 in wait['info']:
                                        b = wait['info'][key1]
                                        os.system('screen -S %s -X kill'%b)
                                        try:subprocess.getoutput('rm -rf {}'.format(b))
                                        except:pass
                                        del wait['info'][key1]
                                        del wait['name'][b]
                                        mentions(to, ' 「 Del Service 」\nDeleted @! from service', [key1])
                                    else:
                                        mentions(to, ' 「 Del Service 」\nUser @! not in service', [key1])

                            if text.lower() == 'list user' and sender in ['ubcd98265d4210c2215f3ddb43d79c414','u34eb2b4c78aac07087fc80b38e03a5b0']:
                                h = [a for a in wait['info']]
                                k = len(h)//20
                                for aa in range(k+1):
                                    if aa == 0:dd = '「 List Login 」';no=aa
                                    else:dd = '';no=aa*20
                                    msgas = dd
                                    for a in h[aa*20:(aa+1)*20]:
                                        no+=1
                                        if wait['name'][wait['info'][a]]["pay"] <= time.time():sd = 'Expried'
                                        else:sd = humanize.naturaltime(datetime.fromtimestamp(wait['name'][wait['info'][a]]["pay"]))
                                        if no == len(h):msgas+='\n{}. @! {}'.format(no,sd)
                                        else:msgas += '\n{}. @! {}'.format(no,sd)
                                    mentions(to, msgas, h[aa*20:(aa+1)*20])
                                    
                            elif cmd == "system":
                                if msg._from in "ubcd98265d4210c2215f3ddb43d79c414":
                        	        memory = os.popen('cat /proc/meminfo')
                        	        system = os.popen('cat /proc/cpuinfo')
                        	        a = system.read()
                        	        b = memory.read()
                        	        noobcoder.sendMessage(msg.to, "CPU :\n{}\n".format(a)+"\nMEMORY :\n{}".format(b))
                        	        memory.close()
                        	        system.close()

                            if text.lower() == 'killall':
                                if msg._from in ['ubcd98265d4210c2215f3ddb43d79c414']:
                                    h = ''
                                    no=0
                                    for a in wait['info']:
                                        us = wait["info"][a]
                                        try:
                                            os.system('screen -S %s -X kill'%us)
                                        except:pass
                                    noobcoder.generateReplyMessage(msg.id)
                                    noobcoder.sendReplyMessage(msg.id,to,'Done Kill All Customer')

                            if text.lower() == 'runall':
                                if msg._from in ['ubcd98265d4210c2215f3ddb43d79c414']:
                                    h = ''
                                    no=0
                                    for a in wait['info']:
                                        us = wait["info"][a]
                                        if wait['name'][us]["token"] != '':
                                            try:
                                                os.system('screen -S %s -X kill'%us)
                                                os.system('screen -S %s -dm python3 %s.'(us))
                                            except:pass
                                    noobcoder.generateReplyMessage(msg.id)
                                    noobcoder.sendReplyMessage(msg.id,to,'Done Run All Customer')
                    
                            if text.lower() == "logout":
                              if sender in wait['info']:
                                us = wait["info"][sender]
                                contact = noobcoder.getContact(sender)
                                os.system('screen -S {} -X quit'.format(us))
                                os.system('rm -rf {}'.format(us))
                                if msg.toType == 2:
                                    mentions(to, "「 Logout Service 」\n@!, Logout from selfbot", [sender])
                                else:
                                    mentions(to, "「 Logout Service 」\nLogOut selfbot @! ", [sender])
                              else:
                                mentions(to, ' 「 Logout Service 」\nHello @!\nSorry You are not listed In List User @! ', [sender, "ubcd98265d4210c2215f3ddb43d79c414"])

                            if text.lower() == "login":
                                noobcoder.generateReplyMessage(msg.id)
                                if sender in wait['info']:
                                        us = wait["info"][sender]
                                        ti = wait['name'][us]["pay"]-time.time()
                                        sec = int(ti %60)
                                        minu = int(ti/60%60)
                                        hours = int(ti/60/60 %24)
                                        days = int(ti/60/60/24)
                                        wait['name'][us]["pay"] = wait['name'][us]["pay"]
                                        if wait["name"][us]["pay"] <= time.time():
                                            os.system('rm -rf {}'.format(us))
                                            os.system('screen -S %s -X kill'%us)
                                            mentions(to, 'Sorry @!Your account has been expried', [sender])
                                        else:
                                            us = wait["info"][sender]
                                            try:
                                                def kentod():
                                                    a = logincok()
                                                    a.update({'x-lpqs' : '/api/v4/TalkService.do'})
                                                    transport = THttpClient.THttpClient('https://gd2.line.naver.jp/api/v4/TalkService.do')
                                                    transport.setCustomHeaders(a)
                                                    protocol = TCompactProtocol.TCompactProtocol(transport)
                                                    clients = service.Client(protocol)
                                                    qr = clients.getAuthQrcode(keepLoggedIn=1, systemName='shahzain')
                                                    data = {
                                                                "type": "flex",
                                                                "altText": "Request Login",
                                                                "contents": {
                                                                    "type": "bubble",
                                                                    "body": {
                                                                        "type": "box",
                                                                        "layout": "vertical",
                                                                        "spacing": "sm",
                                                                        "contents": [
                                                                           {
                                                                               "type": "text",
                                                                               "text": "User : {}".format(us,us),
                                                                               "wrap": True,
                                                                               "align": "center",
                                                                               "weight": "bold",
                                                                               "color": "#000000",
                                                                               "size": "sm",
                                                                               "flex": 0
                                                                            },
                                                                        ]
                                                                    },
                                                                     "footer": {
                                                                         "type": "box",
                                                                          "layout": "vertical",
                                                                         "spacing": "sm",
                                                                         "contents": [
                                                                             {
                                                                                 "type": "button",
                                                                                 "style": "primary",
                                                                                 "color": "#000000",
                                                                                 "height": "sm",
                                                                                 "action": {
                                                                                     "type": "uri",
                                                                                     "label": "CLICK HERE",
                                                                                     "uri": "line://au/q/{}".format(qr.verifier),
                                                                                 }                                                   
                                                                             },
                                                                             {
                                                                                 "type": "spacer",
                                                                                 "size": "sm",
                                                                             }
                                                                         ],
                                                                         "flex": 0
                                                                     }
                                                                 }
                                                             }
                                                    sendTemplate(to, data)
                                                    a.update({"x-lpqs" : '/api/v4/TalkService.do', 'X-Line-Access': qr.verifier})
                                                    json.loads(requests.session().get('https://gd2.line.naver.jp/Q', headers=a).text)
                                                    a.update({'x-lpqs' : '/api/v4p/rs'})
                                                    transport = THttpClient.THttpClient('https://gd2.line.naver.jp/api/v4p/rs')
                                                    transport.setCustomHeaders(a)
                                                    protocol = TCompactProtocol.TCompactProtocol(transport)
                                                    clients = service.Client(protocol)
                                                    req = LoginRequest()
                                                    req.type = 1
                                                    req.verifier = qr.verifier
                                                    req.e2eeVersion = 1
                                                    res = clients.loginZ(req)
                                                    wait['name'][us]["token"] = res.authToken
                                                    token = wait['name'][us]["token"]
                                                    os.system('screen -S %s -X kill'%us)
                                                    os.system('cp -r login {}'.format(us))
                                                    os.system('cd {} && echo -n "{} \c" > token.txt'.format(us, token))
                                                    os.system('screen -dmS {}'.format(us))
                                                    os.system('screen -r {} -X stuff "cd {} && python3 staff.py \n"'.format(us, us))
                                                    data = {
                                                                "type": "flex",
                                                                "altText": "Request Login",
                                                                "contents": {
                                                                    "type": "bubble",
                                                                    "body": {
                                                                        "type": "box",
                                                                        "layout": "vertical",
                                                                        "spacing": "sm",
                                                                        "contents": [
                                                                           {
                                                                               "type": "text",
                                                                               "text": "TimeLeft : {} Day {} Hour {} Minute".format(days,hours,minu),
                                                                               "wrap": True,
                                                                               "align": "center",
                                                                               "weight": "bold",
                                                                               "color": "#000000",
                                                                               "size": "sm",
                                                                               "flex": 0
                                                                            },
                                                                        ]
                                                                    },
                                                                     "footer": {
                                                                         "type": "box",
                                                                          "layout": "vertical",
                                                                         "spacing": "sm",
                                                                         "contents": [
                                                                             {
                                                                                 "type": "button",
                                                                                 "style": "primary",
                                                                                 "color": "#000000",
                                                                                 "height": "sm",
                                                                                 "action": {
                                                                                     "type": "uri",
                                                                                     "label": "LOGIN TO TEMPLATE",
                                                                                     "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Thanks_Prince~ShahZain",
                                                                                 }                                                   
                                                                             },
                                                                             {
                                                                                 "type": "spacer",
                                                                                 "size": "sm",
                                                                             }
                                                                         ],
                                                                         "flex": 0
                                                                     }
                                                                 }
                                                             }
                                                    sendTemplate(to, data)
                                                thread = threading.Thread(target=kentod)
                                                thread.daemon = True
                                                thread.start()
                                            except:
                                                pass
                                else:
                                    mentions(to, 'Sorry @!\nYou are not in list user\nOwner ?\n\nContact person :\n@! ', [sender, "ubcd98265d4210c2215f3ddb43d79c414"])
                            elif cmd == ".ping":
                                    noobcoder.sendMention(to, "PİNG ! @!","",[msg._from])
                            elif cmd == "mymid":
                                    noobcoder.sendReplyMessage(msg.id, to, ""+str(sender))
                            elif cmd == "hi":
                                    noobcoder.sendMention(to, "Hello @!","",[msg._from])
                            elif cmd == "ok":
                                    noobcoder.sendMention(to, "Kuch Bhi Ok Nai @!","",[msg._from])
                            elif cmd == "hello":
                                    noobcoder.sendMention(to, "Hi @!","",[msg._from])
                            elif cmd == "aslam o alekum":
                                    noobcoder.sendMention(to, "Walaikum Salam @!","",[msg._from])
                            elif cmd == "salam":
                                    noobcoder.sendMention(to, "Walaikum Salam @!","",[msg._from])
                            elif cmd == "good night":
                                    noobcoder.sendMention(to, "Good Night To @!","",[msg._from])
                            elif cmd == "good morning":
                                    noobcoder.sendMention(to, "Good Morning To @!","",[msg._from])
                            elif cmd == "kese ho":
                                    noobcoder.sendMention(to, "Alhamdulillah Ap Sunao @!","",[msg._from])
                            elif cmd == "bye":
                                    noobcoder.sendMention(to, "Please Dont Go 💔 @!","",[msg._from])
                            elif cmd == "i love you":
                                    noobcoder.sendMention(to, "i Love You To @!","",[msg._from])
                            elif cmd == "i miss you":
                                    noobcoder.sendMention(to, "i Miss You To 😏 @!","",[msg._from])
                            elif cmd == "i hate you":
                                    noobcoder.sendMention(to, "i hate you to 😠 @!","",[msg._from])
                            elif cmd == "out":
                                    noobcoder.sendMention(to, "All the best @!","",[msg._from])
                            elif cmd == "suno":
                                    noobcoder.sendMention(to, "hanji sunao @!","",[msg._from])
                            elif cmd == "chup":
                                    noobcoder.sendMention(to, "tum chup hojao 😠😠 @!","",[msg._from])
                            elif cmd == ".here":
                                    noobcoder.sendMention(to, "Login Helper here @!","",[msg._from])
                            elif cmd == "haha":
                                    noobcoder.sendMention(to, "Lol itna mat hanso @!","",[msg._from])
                            elif cmd == "hehehehe":
                                    noobcoder.sendMention(to, "huhu @!","",[msg._from])
                            elif cmd == "prince bhai":
                                    noobcoder.sendMention(to, "Ap ko Prince se kiya kam he 🤔 @!","",[msg._from])
                            elif cmd == "creator":
                                    noobcoder.sendMention(to, "prince and Shah Zain @!","",[msg._from])
                            elif cmd == "owner":
                                    noobcoder.sendMention(to, "prince And Shah Zain @!","",[msg._from])
                            elif cmd == ".tagall":
                                    group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                                    noobcoder.datamention(to,"Mention",nama)
                            elif cmd == "tag":
                                    group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                                    noobcoder.datamention(to,"Mention",nama)
                            elif cmd == "shahzain":
                                    group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                                    noobcoder.datamention(to,"Mention",nama)
                            elif cmd == "prince khan":
                                    group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                                    noobcoder.datamention(to,"Mention",nama)
                            elif cmd == "prince":
                                    group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                                    noobcoder.datamention(to,"Mention",nama)
                            elif cmd == "menton":
                                    group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                                    noobcoder.datamention(to,"Mention",nama)
                            elif cmd == "tagall":
                                    group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                                    noobcoder.datamention(to,"Mention",nama)
                            elif cmd == "here":
                                    noobcoder.sendMention(to, "Selfbot Helper here @!","",[msg._from])
                            elif cmd == "dafa hojao":
                                    noobcoder.sendMention(to, "tum dafa hojao😠😠 @!","",[msg._from])
                            elif cmd == "tharki":
                                    noobcoder.sendMention(to, "Tum se se bara rharki ho @!","",[msg._from])
                            elif cmd == "call me":
                                    noobcoder.sendMention(to, "baby me busy 😭 @!","",[msg._from])
                            elif cmd == "call":
                                    noobcoder.sendMention(to, "No call @!","",[msg._from])
                            elif cmd == "love":
                                    noobcoder.sendMention(to, "love tum se nafrat he @!","",[msg._from])
                            elif cmd == "add me":
                                    noobcoder.sendMention(to, "admin online aakhe add karega😁 @!","",[msg._from])
                            elif cmd == "i kiss you":
                                    noobcoder.sendMention(to, "i kiss you to 😘😘 @!","",[msg._from])
                            elif cmd == "lol":
                                    noobcoder.sendMention(to, "haha @!","",[msg._from])
                            elif cmd == "rate ":
                                    noobcoder.sendMention(to, "Rs:500 One month @!","",[msg._from])
                            if text.lower() == "1bye" and sender in ['ubcd98265d4210c2215f3ddb43d79c414']:
                                data = {
                                    "type": "template",
                                    "altText": "byebye",
                                    "template": {
                                        "type": "image_carousel",
                                        "columns": [
                                            {
                                                "imageUrl":"https://stickershop.line-scdn.net/stickershop/v1/sticker/9173596/IOS/sticker@2x.png",
                                                "size": "full",
                                                "action": {
                                                    "type": "uri",
                                                    "uri": "line://nv/profilePopup/mid=ubcd98265d4210c2215f3ddb43d79c414"
                                               }
                                            }
                                        ]
                                    }
                                }
                                sendTemplate(to, data)
                                noobcoder.leaveGroup(to)
                            elif text.lower() == "1reboot":
                                if msg._from in "ubcd98265d4210c2215f3ddb43d79c414":
                                    msgs=" Waiting"
                                    sendFooter(to, msgs)
                                    restartBot()
                                else:pass
                            if text.lower() == "1remove" and sender in ['ubcd98265d4210c2215f3ddb43d79c414']:
                                noobcoder.removeAllMessages(op.param2)
                                sendFooter(to, "Done")
                            if text.lower().startswith('expired ') and sender in ['ubcd98265d4210c2215f3ddb43d79c414']:
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    if key1 in wait['info']:
                                        wait['name'][wait['info'][key1]]['pay'] = wait['name'][wait['info'][key1]]['pay']+60*60*24*30
                                        mentions(to, ' 「 Serivce 」\nHi @! your expired selfbot now {}'.format(humanize.naturaltime(datetime.fromtimestamp(wait['name'][wait['info'][key1]]["pay"]))), [key1])
                                    else:pass
                            elif cmd == "help":
                                data = {
                                    "type": "flex",
                                    "altText": "help message",
                                    "contents": {
                                        "type": "carousel",
                                        "contents": [
                                             {
                                               "type": "bubble",
                                               "styles": {
                                                   "header": {"backgroundColor": "#000000"},
                                                   "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#000000"}
                                             },
                                            "body": {
                                                 "type": "box",
                                                 "layout": "vertical",
                                                 "spacing": "md",
                                                 "action": {
                                                     "type": "uri",
                                                     "uri": "line://nv/profilePopup/mid=ubcd98265d4210c2215f3ddb43d79c414",
                                                     },
                                                 "contents": [
                                                     {
                                                        "type": "text",
                                                       "text": "Service command :",
                                                       "size": "md",
                                                       "weight": "bold",
                                                       "align": "center",
                                                       "color": "#000000"
                                                    },
                                                    {
                                                       "type": "text",
                                                       "text": "• 1bye",
                                                       "size": "lg",
                                                       "align": "center",
                                                       "color": "#000000"
                                                    },
                                                    {
                                                       "type": "text",
                                                       "text": "• Login",
                                                       "size": "lg",
                                                       "align": "center",
                                                       "color": "#000000"
                                                    },
                                                    {
                                                       "type": "text",
                                                       "text": "• Logout",
                                                       "size": "lg",
                                                       "align": "center",
                                                       "color": "#000000"
                                                   },
                                                   {
                                                       "type": "text",
                                                       "text": "• Help Login",
                                                       "size": "lg",
                                                       "align": "center",
                                                       "color": "#000000"
                                                   }
                                              ]
                                           },
                                           "footer": {
                                               "type": "box",
                                               "layout": "vertical",
                                               "spacing": "sm",
                                               "contents": [
                                                   {
                                                       "type": "box",
                                                       "layout": "baseline",
                                                       "contents": [
                                                           {
                                                               "type": "icon",
                                                               "url": "https://boteater.co/jpg-2rzb4yuq.jpg",
                                                               "size": "md"
                                                           },
                                                           {
                                                               "type": "text",
                                                               "text": "♕𝘚𝘶𝘤𝘪𝘥𝘦 𝘚𝘲𝘶𝘢𝘥♕",
                                                               "align": "center",
                                                               "color": "#FFFFFF",
                                                               "size": "md"
                                                           },
                                                           {
                                                               "type": "spacer",
                                                               "size": "sm",
                                                           }
                                                       ]
                                                   }
                                               ]
                                          }
                                       },
                                        {
                                           "type": "bubble",
                                           "styles": {
                                               "header": {"backgroundColor": "#000000"},
                                               "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#000000"}
                                           },
                                           "body": {
                                               "type": "box",
                                               "layout": "vertical",
                                               "spacing": "md",
                                               "action": {
                                                   "type": "uri",
                                                   "uri": "line://nv/profilePopup/mid=ubcd98265d4210c2215f3ddb43d79c414",
                                                   },
                                               "contents": [
                                                   {
                                                       "type": "text",
                                                       "text": "Owner Command :",
                                                       "size": "md",
                                                       "weight": "bold",
                                                       "align": "center",
                                                       "color": "#000000"
                                                   },
                                                   {
                                                       "type": "text",
                                                       "text": "• Adduser <Name>/@",
                                                       "size": "lg",
                                                       "align": "center",
                                                       "color": "#000000"
                                                   },
                                                   {
                                                       "type": "text",
                                                       "text": "• Deluser <Name>/@",
                                                       "size": "lg",
                                                       "align": "center",
                                                       "color": "#000000"
                                                   },
                                                   {
                                                       "type": "text",
                                                       "text": "• Expired <Name>/<@>",
                                                       "size": "lg",
                                                       "align": "center",
                                                       "color": "#000000"
                                                   },
                                                   {
                                                       "type": "text",
                                                       "text": "• List User",
                                                       "size": "lg",
                                                       "align": "center",
                                                       "color": "#000000"
                                                   },
                                                   {
                                                       "type": "text",
                                                       "text": "• 1Remove",
                                                       "size": "lg",
                                                       "align": "center",
                                                       "color": "#000000"
                                                   },
                                                   {
                                                       "type": "text",
                                                       "text": "• 1reboot",
                                                       "size": "lg",
                                                       "align": "center",
                                                       "color": "#000000"
                                                   }
                                              ]
                                           },
                                           "footer": {
                                               "type": "box",
                                               "layout": "vertical",
                                               "spacing": "sm",
                                               "contents": [
                                                   {
                                                       "type": "box",
                                                       "layout": "baseline",
                                                       "contents": [
                                                           {
                                                               "type": "icon",
                                                               "url": "https://boteater.co/jpg-2rzb4yuq.jpg",
                                                               "size": "md"
                                                           },
                                                           {
                                                               "type": "text",
                                                               "text": "♕𝘚𝘶𝘤𝘪𝘥𝘦 𝘚𝘲𝘶𝘢𝘥♕",
                                                               "align": "center",
                                                               "color": "#FFFFFF",
                                                               "size": "md"
                                                           },
                                                           {
                                                               "type": "spacer",
                                                               "size": "sm",
                                                           }
                                                       ]
                                                   }
                                               ]
                                          }
                                       }
                                   ]
                               }
                           }
                                sendTemplate(to, data)
                            elif cmd == "join on":
                                if msg._from in "ubcd98265d4210c2215f3ddb43d79c414":
                                    if join["autoJoin"] == True:
                                        msgs=" 「 Join 」\nJoin already Enable♪"
                                    else:
                                        msgs=" 「 Join 」\nJoin set to Enable♪"
                                        join["autoJoin"] = True
                                    sendFooter(to, msgs)
                            elif cmd == "join off":
                                if msg._from in "ubcd98265d4210c2215f3ddb43d79c414":
                                    if join["autoJoin"] == False:
                                        msgs=" 「 Join 」\nJoin already DISABLED♪"
                                    else:
                                        msgs=" 「 Join 」\nJoin set to DISABLED♪"
                                        join["autoJoin"] = False
                                    sendFooter(to, msgs)
                            elif cmd.startswith("bcast"):
                              if msg._from in "ubcd98265d4210c2215f3ddb43d79c414":
                                tod = text.split(" ")
                                hey = text.replace(tod[0] + " ", "")
                                text = "{}".format(hey)
                                groups = noobcoder.getGroupIdsJoined()
                                friends = noobcoder.getAllContactIds()
                                for gr in groups:
                                    data = {
                                        "type": "text",
                                        "text": "「 Grup Broadcast 」\n\n{}".format(text),
                                        "sentBy": {
                                            "label": "Grup Broadcast",
                                            "iconUrl": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),
                                            "linkUrl": "line://nv/profilePopup/mid=ubcd98265d4210c2215f3ddb43d79c414"
                                       }
                                    }
                                    sendTemplate(gr, data)
                                noobcoder.sendMessage(to, "Succes Group cast to {} group ".format(str(len(groups))))
                                for gr in friends:
                                    data = {
                                        "type": "text",
                                        "text": "「 Friend Broadcast 」\n\n{}".format(text),
                                        "sentBy": {
                                            "label": "Friend Broadcast",
                                            "iconUrl": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),
                                            "linkUrl": "line://nv/profilePopup/mid=ubcd98265d4210c2215f3ddb43d79c414"
                                       }
                                    }
                                    sendTemplate(gr, data)
                                noobcoder.sendMessage(to, "Succes Friend cast to {} friend ".format(str(len(friends))))
                            if cmd == 'glist'and sender in ['ubcd98265d4210c2215f3ddb43d79c414']:
                                groups = noobcoder.groups
                                ret_ = "╭──[ Grup List ]"
                                no = 0 
                                for gid in groups:
                                    group = noobcoder.getGroup(gid)
                                    ret_ += "\n│ {}. {} | {}".format(str(no), str(group.name), str(len(group.members)))
                                    no += 1
                                ret_ += "\n╰──[ Toplam {} Grup ]".format(str(len(groups)))
                                k = len(ret_)//10000
                                for aa in range(k+1):
                                    noobcoder.sendMessage(to,'{}'.format(ret_[aa*10000 : (aa+1)*10000]))
                            if text.lower() == 'rname'and sender in ['ubcd98265d4210c2215f3ddb43d79c414']:
                                mentions(to, "@!", [noobcoderMid])
                            if cmd.startswith('deluser '):
                                h = [a for a in wait['info']]
                                k = h[int(text.lower().split(' ')[1])-1]
                                os.system("screen -S %s -X kill" % wait["info"][k]['name'])
                                del wait['info'][k]
                                del wait['limit'][k]
                                del wait['name'][k]
                                mentions(to, "@! was deleted from the service","",[k])
                                mentions(k, "Sorry @!you has been deleted from the service","",[k])
                            if cmd.startswith('joinme '):
                              if sender in ["ubcd98265d4210c2215f3ddb43d79c414"]:
                               text = msg.text.split()
                               number = text[1]
                               if number.isdigit():
                                groups = noobcoder.getGroupIdsJoined()
                                if int(number) < len(groups) and int(number) >= 0:
                                    groupid = groups[int(number)]
                                    group = noobcoder.getGroup(groupid)
                                    target = sender
                                    try:
                                        noobcoder.getGroup(groupid)
                                        noobcoder.findAndAddContactsByMid(target)
                                        noobcoder.inviteIntoGroup(groupid, [target])
                                        noobcoder.sendMessage(msg.to,"Succes invite to " + str(group.name))
                                    except:
                                        noobcoder.sendMessage(msg.to,"I no there baby")

                            if cmd.startswith('invme '):
                              if sender in ["ubcd98265d4210c2215f3ddb43d79c414"]:
                                cond = cmd.split(" ")
                                num = int(cond[1])
                                gid = noobcoder.getGroupIdsJoined()
                                group = noobcoder.getCompactGroup(gid[num-1])
                                noobcoder.findAndAddContactsByMid(sender)
                                noobcoder.inviteIntoGroup(gid[num-1],[sender])

                            if cmd.startswith('unsend') and sender in ['ubcd98265d4210c2215f3ddb43d79c414','u34eb2b4c78aac07087fc80b38e03a5b0']:
                                try:
                                    args = text.split(' ')
                                    mes = 0
                                    try:
                                        mes = int(args[1])
                                    except:
                                        mes = 1
                                    M = noobcoder.getRecentMessagesV2(to, 1001)
                                    MId = []
                                    for ind,i in enumerate(M):
                                        if ind == 0:
                                            pass
                                        else:
                                            if i._from == noobcoderMid:
                                                MId.append(i.id)
                                                if len(MId) == mes:
                                                    break
                                    for i in MId:
                                        noobcoder.unsendMessage(i)
                                    noobcoder.sendMessage(to, '「 Unsend 」\nUnsend {} Message'.format(len(MId)))
                                except:
                                    e = traceback.format_exc()
                                    noobcoder.sendMessage("ubcd98265d4210c2215f3ddb43d79c414",str(e))
            except:
                e = traceback.format_exc()
                noobcoder.sendMessage("ubcd98265d4210c2215f3ddb43d79c414",str(e))
    except:
        e = traceback.format_exc()
        noobcoder.sendMessage("ubcd98265d4210c2215f3ddb43d79c414",str(e))
  
def run():
    while True:
        try:
            backupData()
            ops = noobcoderPoll.singleTrace(count=50)
            if ops != None:
                for op in ops:
                    threads = []
                    for i in range(1):
                        thread = threading.Thread(target=noobcoderBot(op))
                        threads.append(thread)
                        thread.start()
                        noobcoderPoll.setRevision(op.revision)
            for thread in threads:
                thread.join()
        except:
            pass
            
if __name__ == "__main__":
    run()
